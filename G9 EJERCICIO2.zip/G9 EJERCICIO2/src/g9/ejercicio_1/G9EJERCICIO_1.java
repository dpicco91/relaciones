

package g9.ejercicio_1;

import Servicios.JuegoServicio;
import Servicios.JugadorServicio;

import Servicios.RevolverServicio;

public class G9EJERCICIO_1 {

    public static void main(String[] args) {
        JuegoServicio juSer= new JuegoServicio();
        RevolverServicio rs = new RevolverServicio();
        JugadorServicio js = new JugadorServicio();
        
        
        
        juSer.llenarJuego(js.crearJugador(), rs.llenarRevolver());
        juSer.ronda();
    }

}
