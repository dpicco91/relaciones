
package Servicios;

import Entidades.Juego;
import Entidades.Jugador;
import Entidades.Revolver;
import java.util.ArrayList;

public class JuegoServicio {
    Juego j1 = new Juego();
    public void llenarJuego(ArrayList<Jugador>jugadores, Revolver r ){
    
    j1.setJugadores(jugadores);
    j1.setRevolver(r);
    }
    
    public void ronda(){
        JugadorServicio js =  new JugadorServicio();
        boolean x=false;
        do{           
        for (Jugador aux : j1.getJugadores()) {
            System.out.println(j1.getRevolver().toString());
            if(js.disparo(j1.getRevolver())){
                aux.setMojado(true);
                System.out.println("El "+aux.getNombre()+" se ha mojado");
                x=true;
                break;
            }
        }
        }while(x==false);
    }
}
