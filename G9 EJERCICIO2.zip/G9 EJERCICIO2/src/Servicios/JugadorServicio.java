package Servicios;

import Entidades.Jugador;
import Entidades.Revolver;
import java.util.ArrayList;
import java.util.Scanner;

public class JugadorServicio {
    Scanner leer = new Scanner(System.in).useDelimiter("\n");
    
    public ArrayList<Jugador> crearJugador(){
        ArrayList<Jugador>numJugadores = new ArrayList();
        System.out.println("Ingrese el numero de jugadores");
        int num=leer.nextInt();
        
        if(num<1|| num>6){
            num=6;
        }
        for (int i = 1; i <= num; i++) {
        
        Jugador j = new Jugador();


        j.setNombre("Jugador "+i);
        j.setMojado(false);
        j.setId(i);
        numJugadores.add(j);
        }        
        return numJugadores;
    }

    public boolean disparo(Revolver r1) {
        boolean mojar = false;
        RevolverServicio rs = new RevolverServicio();
        if (rs.mojar(r1)) {
            mojar = true;
        }else{
            rs.siguienteChorro(r1);
        }
        
        return mojar;
    }
}
