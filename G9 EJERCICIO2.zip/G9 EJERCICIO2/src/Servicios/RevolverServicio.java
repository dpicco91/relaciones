package Servicios;

import Entidades.Revolver;

public class RevolverServicio {

    public Revolver llenarRevolver() {
        Revolver r1 = new Revolver();
        r1.setPosicionActual((int) (Math.random() * 6));
        r1.setPosicionAgua((int) (Math.random() * 6));
        return r1;
    }
    

    public boolean mojar(Revolver r1) {
       
        boolean vr = false;
        if (r1.getPosicionActual() == r1.getPosicionAgua()) {
            vr = true;
        }
        return vr;
    }
    
    public void siguienteChorro(Revolver r1){
        if(r1.getPosicionActual()==5){
            r1.setPosicionActual(0);
        }else{
            r1.setPosicionActual(r1.getPosicionActual()+1);
        }
    }
    
    public void mostarPosicion(Revolver r1){
        System.out.println(r1.toString());
    }
}
